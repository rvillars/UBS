package com.ubs.C6U.configurer;

import org.springframework.boot.autoconfigure.security.servlet.PathRequest;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

@Configuration
@EnableWebSecurity
@Order(9) // Has to be before Flowable WebSecurityConfigurerAdapter
public class H2SecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.requestMatcher(PathRequest.toH2Console())
                .csrf().disable()
                .headers().frameOptions().sameOrigin().and()
                .authorizeRequests().anyRequest().permitAll();
    }
}
