package com.ubs.C6U.configurer;

import com.flowable.platform.common.security.SecurityConstants;
import com.flowable.platform.spring.security.web.authentication.AjaxAuthenticationFailureHandler;
import com.flowable.platform.spring.security.web.authentication.AjaxAuthenticationSuccessHandler;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.annotation.Order;
import org.springframework.http.HttpStatus;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.HttpStatusEntryPoint;
import org.springframework.security.web.authentication.logout.HttpStatusReturningLogoutSuccessHandler;
import org.springframework.security.web.util.matcher.AnyRequestMatcher;

@Configuration
@EnableWebSecurity
@Order(10)
public class EmbeddedFrontendSecurityConfigurerAdapter extends WebSecurityConfigurerAdapter {

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                // In case you want to disable JSESSIONID cookies.
                // Flowable's Authentication class expects AuthenticationSuccessEvent to be fired
                // every time, and sending the cookie makes it fail from time to time. Check class
                // SecurityAutoConfiguration for insights on how is this configured.
                // Two things to notice:
                // 1. You have to add basic auth to /frontend/engage/api/auth.ts
                //    Axios.defaults.auth = { username, password };
                // 2. WebSockets+SocksJS, https://github.com/sockjs/sockjs-client/issues/196
                //.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS)
                //.and()
                .logout()
                .logoutSuccessHandler(new HttpStatusReturningLogoutSuccessHandler())
                .logoutUrl("/auth/logout")
                .and()
                // Non authenticated exception handling. The formLogin and httpBasic configure the exceptionHandling
                // We have to initialize the exception handling with a default authentication entry point in order to return 401 each time and not have a
                // forward due to the formLogin or the http basic popup due to the httpBasic
                .exceptionHandling()
                .defaultAuthenticationEntryPointFor(new HttpStatusEntryPoint(HttpStatus.UNAUTHORIZED), AnyRequestMatcher.INSTANCE)
                .and()
                .formLogin()
                .loginProcessingUrl("/auth/login")
                .successHandler(new AjaxAuthenticationSuccessHandler())
                .failureHandler(new AjaxAuthenticationFailureHandler())
                .and()
                .authorizeRequests()
                .antMatchers("/analytics-api/**").hasAuthority(SecurityConstants.ACCESS_REPORTS_METRICS)
                .antMatchers("/template-api/**").hasAuthority(SecurityConstants.ACCESS_TEMPLATE_MANAGEMENT)
                .antMatchers("/work-object-api/**").hasAuthority(SecurityConstants.ACCESS_WORKOBJECT_API)
                .antMatchers("/engage-ubs-api/**").hasAuthority(SecurityConstants.ACCESS_COMPLIANCE) // TODO: shouldn't this be a more specific URL like -archiving-api?
                // allow context root for all (it triggers the loading of the initial page)
                .antMatchers("/") .permitAll()
                .antMatchers(
                        "/**/*.svg", "/**/*.ico", "/**/*.png", "/**/*.woff2", "/**/*.css",
                        "/**/*.woff", "/**/*.html", "/**/*.js",
                        "/**/index.html").permitAll()
                .anyRequest().authenticated()
                .and()
                .httpBasic();
    }
}
