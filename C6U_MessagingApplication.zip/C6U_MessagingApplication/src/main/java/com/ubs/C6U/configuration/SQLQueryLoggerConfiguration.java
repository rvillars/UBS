package com.ubs.C6U.configuration;

import com.ubs.C6U.processor.DatasourceProxyBeanPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
@ConditionalOnProperty("flowable.datasource.query.logging.enabled")
public class SQLQueryLoggerConfiguration {

    @Bean
    BeanPostProcessor sqlQueryLoggingBeanPostProcessor() {
        return new DatasourceProxyBeanPostProcessor();
    }

}
