package com.ubs.C6U.configuration;

import org.apache.catalina.Manager;
import org.apache.catalina.session.ManagerBase;
import org.apache.catalina.session.StandardManager;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.server.WebServerFactoryCustomizer;
import org.springframework.context.annotation.Configuration;

@Configuration
public class EmbeddedTomcatConfiguration {

    @Value("${flowable.embedded.tomcat.jvmRoute}")
    private String jvmRoute;

    public WebServerFactoryCustomizer<TomcatServletWebServerFactory> servletContainer() {
        return (tomcat) -> tomcat.addContextCustomizers((context -> {
            Manager manager = context.getManager();
            if (manager == null) {
                manager = new StandardManager();
                context.setManager(manager);
            }
            if (jvmRoute != null) {
                ((ManagerBase) context.getManager()).getEngine().setJvmRoute(jvmRoute);
            }
        }));
    }
}
