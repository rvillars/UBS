package com.ubs.C6U.configuration;

import com.flowable.engage.autoconfigure.websocket.WebSocketMessageBrokerProperties;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.messaging.MessageSecurityMetadataSourceRegistry;
import org.springframework.security.config.annotation.web.socket.AbstractSecurityWebSocketMessageBrokerConfigurer;

/**
 * Template security configuration for the websockets.
 *
 * @author Filip Hrisafov
 */
@Configuration
public class WebSocketSecurityConfiguration extends AbstractSecurityWebSocketMessageBrokerConfigurer {

    protected final WebSocketMessageBrokerProperties brokerProperties;

    public WebSocketSecurityConfiguration(WebSocketMessageBrokerProperties brokerProperties) {
        this.brokerProperties = brokerProperties;
    }

    @Override
    protected void configureInbound(MessageSecurityMetadataSourceRegistry messages) {
        // In case there are destination prefixes deny all of them as they are forwarded to the broker
        String[] destinationPrefixes = brokerProperties.getDestinationPrefixes();
        if (destinationPrefixes != null) {
            for (String destinationPrefix : destinationPrefixes) {
                messages.simpMessageDestMatchers(destinationPrefix + "/**").denyAll();
            }
        }
        messages.anyMessage().authenticated();
    }

    @Override
    protected boolean sameOriginDisabled() {
        //disable CSRF for websockets for now...
        return true;
    }
}
