package com.ubs.C6U;

import com.flowable.engage.autoconfigure.config.EngageEngineStompAutoConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;
import org.springframework.web.socket.config.annotation.EnableWebSocketMessageBroker;

@EnableWebSocketMessageBroker
@SpringBootApplication(exclude = {
		FreeMarkerAutoConfiguration.class,
		EngageEngineStompAutoConfiguration.class
})
public class C6UMessagingApplication {

	public static void main(String[] args) {
		SpringApplication.run(C6UMessagingApplication.class, args);
	}
}
