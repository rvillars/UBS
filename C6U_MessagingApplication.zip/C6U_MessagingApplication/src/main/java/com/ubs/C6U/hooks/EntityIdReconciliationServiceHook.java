package com.ubs.C6U.hooks;

import com.flowable.addons.ubs.sso.ldap.api.Account;
import com.flowable.addons.ubs.sso.ldap.api.GroupId;
import com.flowable.addons.ubs.sso.reconciliation.api.ReconciliationAccount;
import com.flowable.addons.ubs.sso.reconciliation.api.ReconciliationServiceHook;
import com.flowable.platform.idm.api.PlatformUserBuilder;
import org.springframework.stereotype.Component;

import java.util.TreeSet;

import static java.util.stream.Collectors.toCollection;

@Component
public class EntityIdReconciliationServiceHook implements ReconciliationServiceHook {

    private static final String ENTITY_ID_VALUE_SG_SUFFIX = "_046";
    private static final String ENTITY_ID_KEY = "entityId";
    private static final String ENTITY_ID_VALUE_SG = "SG-046";
    private static final String ENTITY_ID_VALUE_HK = "HK-030";

    @Override
    public void postReconcileAccount(PlatformUserBuilder platformUserBuilder, Account ldapAccount, ReconciliationAccount reconciliationAccount) {
        String primaryGroupId = ldapAccount.getGroupIds()
                .stream()
                .map(GroupId::getValue)
                .collect(toCollection(TreeSet::new)).first();
        if (primaryGroupId.endsWith(ENTITY_ID_VALUE_SG_SUFFIX)) {
            platformUserBuilder.setInfo(ENTITY_ID_KEY, ENTITY_ID_VALUE_SG);
        } else {
            platformUserBuilder.setInfo(ENTITY_ID_KEY, ENTITY_ID_VALUE_HK);
        }
    }
}
