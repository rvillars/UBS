# Architecture Pattern 003

- Flowable Work
- Clustered
- Nginx load balancing
- SSL Transport encryption for Elasticsearch and browser

## Overview

![Diagram](https://github.com/edorasware/flowable-architecture-pattern/raw/master/003-work-clustered-nginx-ssl.png)

## Comparison

### [002-work-clustered-nginx](../002-work-clustered-nginx/)

- elasticsearch.yml: X-Pack configuration enabling SSL for HTTP and Transport endpoints.
- elasticsearch.yml: X-Pack configuration loading keystore and truststore files.
- elasticsearch.yml: X-Pack configuration disabling hostname verification (remove for productive env).
- application.properties: Use of https instead of http in elasticsearch addresses.
- application.properties: ESLocal addon configuration loading keystore and truststore client files.
- application.properties: ESLocal addon configuration disabling hostname verification (remove for productive env).
- nginx.conf: Added HTTP to HTTPS forwarding
- nginx.conf: Added HTTPS server loading SSL certificates