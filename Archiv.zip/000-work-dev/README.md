# Architecture Pattern 009

- Flowable Work
- In-IDE development setup

## Overview

![Diagram](https://github.com/edorasware/flowable-architecture-pattern/raw/master/000-work-dev.png)

## Comparison