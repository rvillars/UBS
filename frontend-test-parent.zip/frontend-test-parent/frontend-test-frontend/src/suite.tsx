import {PieChartComponent} from "./charts/pie.component";

export default {
    chartPie: PieChartComponent
};