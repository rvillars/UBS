import {PieChartComponent} from "./charts/pie.component";

const formComponents = [
    ['chartPie', PieChartComponent]
];

export default {formComponents};