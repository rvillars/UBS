package com.frontend.test.work;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.freemarker.FreeMarkerAutoConfiguration;

@SpringBootApplication(exclude = {FreeMarkerAutoConfiguration.class})
public class FrontendTestWorkApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrontendTestWorkApplication.class, args);
    }
}
