package com.frontend.test.design;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FrontendTestDesignApplication {

    public static void main(String[] args) {
        SpringApplication.run(FrontendTestDesignApplication.class, args);
    }
}
