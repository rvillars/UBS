package com.training.handson.control;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingHandsonControlApplication {

    public static void main(String[] args) {
        SpringApplication.run(TrainingHandsonControlApplication.class, args);
    }
}
