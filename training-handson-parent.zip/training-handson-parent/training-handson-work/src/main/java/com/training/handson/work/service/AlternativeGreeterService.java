package com.training.handson.work.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service
public class AlternativeGreeterService {

    private static final Logger LOG = LoggerFactory.getLogger(AlternativeGreeterService.class);

    public void greet(String greeter, String personToBeGreeted) {
        LOG.warn(greeter+" says: Alternative Hello "+personToBeGreeted);
    }
}
