package com.training.handson.work.service;

import com.flowable.core.idm.api.PlatformIdentityService;
import com.flowable.core.idm.api.PlatformUser;
import com.flowable.platform.tasks.AbstractPlatformTask;
import com.flowable.platform.tasks.BaseExtensionElement;
import com.flowable.platform.tasks.ExtensionElementsContainer;
import org.flowable.cmmn.api.CmmnRuntimeService;
import org.flowable.common.engine.api.FlowableIllegalArgumentException;
import org.flowable.common.engine.api.variable.VariableContainer;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.delegate.BpmnError;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class GreeterService extends AbstractPlatformTask {

    private static final Logger LOG = LoggerFactory.getLogger(GreeterService.class);

    @Autowired
    PlatformIdentityService platformIdentityService;

    @Override
    public void executeTask(VariableContainer variableContainer, ExtensionElementsContainer extensionElementsContainer) {

        // Tight Coupling: Get the value of the greeter variable directly from the process INSTANCE via variableContainer.
        // String greeter = (String)variableContainer.getVariable(greeterAttributeValue);
        // String personToBeGreeted = (String)variableContainer.getVariable(personToBeGreetedAttributeValue);

        // Loose Coupling: Use a custom service task to let the modeler define on the MODEL, the variable he wants to use as the input for the code.
        // 2 possibilities:

        // Step by step
        // 1. get the expression defined in the MODEL from the extensionElementsContainer
        String greeterExpression = extensionElementsContainer.getExtensionElement("greeter-property").get().getText();
        // 2. resolve the expression to a variable name and get the actual value from the variableContainer
        String greeter = this.resolveValue(variableContainer, greeterExpression);

        // Alternatively, do it all in one step by using the getStringExtensionElementValue convenience method.
        String personToBeGreeted = this.getStringExtensionElementValue("to-be-greeted-property",extensionElementsContainer, variableContainer, "");

        if (personToBeGreeted.equals("admin")) {
            throw new BpmnError("personNotGreetable");
        }

        if (personToBeGreeted.equals(greeter)) {
            throw new RuntimeException("Greeter and Person to be greeted cannot be the same");
        }

        PlatformUser greeterUser = platformIdentityService.createPlatformUserQuery().userId(greeter).singleResult();
        PlatformUser personToBeGreetedUser = platformIdentityService.createPlatformUserQuery().userId(personToBeGreeted).singleResult();

        LOG.warn(greeterUser.getDisplayName()+" says: Hello "+personToBeGreetedUser.getDisplayName());
    }
}
