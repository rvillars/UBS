package com.training.handson.work.service;

import com.flowable.app.engine.test.AppDeployment;
import com.training.handson.work.TrainingHandsonWorkApplication;
import org.flowable.engine.HistoryService;
import org.flowable.engine.RuntimeService;
import org.flowable.engine.TaskService;
import org.flowable.engine.history.HistoricProcessInstance;
import org.flowable.engine.runtime.ProcessInstance;
import org.flowable.task.api.Task;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.util.HashMap;
import java.util.Map;

import static org.assertj.core.api.Assertions.assertThat;

@SpringBootTest(classes = {TrainingHandsonWorkApplication.class})
@ActiveProfiles("test")
@AppDeployment(resources = {"apps/HelloWorldApp-bar.zip"})
public class GreeterServiceIT {

    @Autowired
    RuntimeService runtimeService;

    @Autowired
    TaskService taskService;

    @Autowired
    HistoryService historyService;

    @Test
    public void testHappyPath() {
        ProcessInstance processInstance = runtimeService.startProcessInstanceByKey("helloWorldProcess");
        Task task = taskService.createTaskQuery().processInstanceId(processInstance.getId()).singleResult();
        assertThat(task).isNotNull();

        Map<String, Object> variables = new HashMap<>();
        variables.put("greeter", "admin");
        variables.put("personToBeGreeted", "admin");

        taskService.complete(task.getId(), variables);

        HistoricProcessInstance historicProcessInstance = historyService.createHistoricProcessInstanceQuery().processInstanceId(processInstance.getId()).finished().singleResult();
        assertThat(historicProcessInstance).isNotNull();
    }
}
