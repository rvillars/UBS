package com.training.handson.work;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
class TrainingHandsonWorkApplicationTest {

    @Test
    void canStartContext() {

    }
}