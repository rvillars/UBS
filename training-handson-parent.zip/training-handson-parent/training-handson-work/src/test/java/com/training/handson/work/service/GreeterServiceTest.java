package com.training.handson.work.service;

import com.flowable.core.idm.api.PlatformIdentityService;
import com.flowable.core.idm.api.PlatformUser;
import com.flowable.core.idm.api.PlatformUserQuery;
import com.flowable.idm.engine.impl.persistence.entity.PlatformUserEntityImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

class GreeterServiceTest {

    @InjectMocks
    AlternativeGreeterService greeterService;

    @Mock
    PlatformIdentityService platformIdentityService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void greetTest() {

        PlatformUser flowableAdmin = new PlatformUserEntityImpl();
        flowableAdmin.setDisplayName("Flowwable Admin");

        PlatformUser customer1 = new PlatformUserEntityImpl();
        customer1.setDisplayName("Customer One");
        Mockito.when(platformIdentityService.createPlatformUserQuery()).thenReturn(Mockito.mock(PlatformUserQuery.class));
        Mockito.when(platformIdentityService.createPlatformUserQuery().userId(Mockito.anyString())).thenReturn(Mockito.mock(PlatformUserQuery.class));
        Mockito.when(platformIdentityService.createPlatformUserQuery().userId("admin").singleResult()).thenReturn(flowableAdmin);
        Mockito.when(platformIdentityService.createPlatformUserQuery().userId("customer1").singleResult()).thenReturn(customer1);

        greeterService.greet("admin", "customer1");
    }
}