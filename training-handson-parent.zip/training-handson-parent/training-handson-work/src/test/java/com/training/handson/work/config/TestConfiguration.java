package com.training.handson.work.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class TestConfiguration {
}
